<h1>Altay<img src="http://fs1.directupload.net/images/180401/urn5z9ic.png" height="64" width="64" align="left"></img></h1>
<br />

A feature-rich server software for Minecraft: Bedrock/W10 Edition. Altay is a fork of [pmmp](https://github.com/pmmp/PocketMine-MP)

| Jenkins | TravisCI | Discord | Twitter |
| :---: | :---: | :---: | :---: |
| [![Build Status](https://altay.minehub.de/job/Altay/badge/icon)](https://altay.minehub.de/job/Altay/) | [![Travis branch](https://img.shields.io/travis/TuranicTeam/Altay/master.svg?style=flat-square)](https://travis-ci.org/TuranicTeam/Altay) | [![Discord](https://img.shields.io/discord/427472879072968714.svg?style=flat-square&label=discord&colorB=7289da)](https://discord.gg/UsuhCFj) | [![Twitter Follow](https://img.shields.io/twitter/follow/TuranicTeam.svg?style=flat-square&logo=twitter&label=Follow)](https://twitter.com/TuranicTeam) |


## Why should I choose Altay?

Because Altay has more features and improvements than PocketMine-MP
and its more near to Vanilla MC: BE

## What about plugins?

Don't worry. Altay is tracking the PocketMine-MP API so most of pmmp plugins will support Altay

Altay hasn't very API changes compared to PocketMine-MP. Maybe a little bit :)

## Can I test this before I download it?

Yes, you can.

Here. Some servers that using Altay software:

- **entengames.net:19132**
- **play.oyungg.net:19132**
- **play.zerotouch.tk:19132**
- **angelpe.hu:19132**
- **rushnation.net:19132**
- **play.minetopya.tk:19132**
- **oyna.deathmcpe.com:19132**

By the way, you can tell us to add your server to this list from our Discord group if your server is using Altay.

## Do you need help about Altay?

Join our Discord group and contact us!


###### However may be good if you read rules channel when you joined first time :)
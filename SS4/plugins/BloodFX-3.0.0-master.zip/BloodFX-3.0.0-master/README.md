# BloodFX-3.0.0
## ! WELCOME FROM 7WDEV !

#### How To Use?
1-just install the plugin from poggit (also if you want you can install it from github) !
2-put this plugin in the plugins folder :
```
Server\plugins\BloodFX-3.0.0.phar
                      |
                     \ /
              this is the plugin
              _________________
```
3-enjoy ! (there isn't any command or permission , only try to hit someone and it will work) !
* [POGGIT](#) - plugin installing link from poggit !


#### Info
plugin developed by : 7awariGamer[7Wdev] !
this is a free plugin for all pmmp users !
it is working with 3.0.0 api !

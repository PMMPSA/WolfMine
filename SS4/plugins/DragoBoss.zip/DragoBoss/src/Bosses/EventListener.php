<?php


namespace Bosses;


use Bosses\Entities\ForgottenKing;
use Bosses\Entities\ForgottenNome;
use pocketmine\entity\Entity;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDeathEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\item\Item;
use pocketmine\Player;

class EventListener implements Listener
{

    public function __construct(Loader $plugin){
        $this->plugin = $plugin;
    }

    public function onTap(PlayerInteractEvent $event) {
        $item = $event->getItem();
        $player = $event->getPlayer();
        if ($item->getId() === Item::BONE && $item->getDamage() === 1) {
            if (!$item->hasCustomBlockData()) return;
            $boss = $item->getCustomBlockData()->getString("boss");
            $bone = Item::get(Item::BONE, 1, 1);
            $touch = $event->getTouchVector();
            $spawnAt = $player->add($touch->getX(), $touch->getY(), $touch->getZ());
            $entity = Entity::createEntity($boss, $player->getLevel(), Entity::createBaseNBT($spawnAt));
				if($entity !== null){
            	 $entity->setNameTag("§r§3Forgotten §7Nome");
           	 	 $entity->setNameTagAlwaysVisible(true);
            	 $entity->spawnToAll();
           		 $player->getInventory()->removeItem($bone);
				}
        }

        if ($item->getId() === Item::BONE && $item->getDamage() === 2) {
            if (!$item->hasCustomBlockData()) return;
            $boss = $item->getCustomBlockData()->getString("boss");
            $bone = Item::get(Item::BONE, 1, 1);
            $touch = $event->getTouchVector();
            $spawnAt = $player->add($touch->getX(), $touch->getY(), $touch->getZ());
            $entity = Entity::createEntity($boss, $player->getLevel(), Entity::createBaseNBT($spawnAt));
				 if($entity !== null){
             	$entity->setNameTag("§r§3Forgotten §7King");
           	   $entity->setNameTagAlwaysVisible(true);
             	$entity->spawnToAll();
             	$player->getInventory()->removeItem($bone);
 				}
        }
    }

    public function onDeath(EntityDeathEvent $event) {
        $nome = [
            Item::get(54, 2, 1)->setCustomName("§r§7Basic box"),
            Item::get(54, 4, mt_rand(1, 2))->setCustomName("§r§7Expert box"),
            Item::get(467, 1, 1)->setCustomName("§r§7Minion Rank Orb"),
            Item::get(351, 5, mt_rand(1, 3))->setCustomName("§r§7Metronic Flare"),
            Item::get(Item::BOOK, 1, mt_rand(1, 10))->setCustomName("§r§7Mystery Custom Enchant Book"),
            Item::get(381, 1, 1)->setCustomName("§r§7Paranorma GKit"),
        ];

        $king = [
            Item::get(54, 2, 1)->setCustomName("§r§7Basic box"),
            Item::get(54, 4, mt_rand(1, 2))->setCustomName("§r§7Expert box"),
            Item::get(54, 5, mt_rand(0, 1))->setCustomName("§r§7Legendary box"),
            Item::get(467, 1, 1)->setCustomName("§r§7Minion Rank Orb"),
            Item::get(467, 2, 1)->setCustomName("§r§7Fury Rank Orb"),
            Item::get(351, 5, mt_rand(1, 3))->setCustomName("§r§7Metronic Flare"),
            Item::get(Item::BOOK, 1, mt_rand(1, 10))->setCustomName("§r§7Mystery Custom Enchant Book"),
            Item::get(381, 1, 1)->setCustomName("§r§7Paranorma GKit"),
            Item::get(381, 2, 1)->setCustomName("§r§7Alastor GKit")
        ];
        $boss = $event->getEntity();
        $cause = $event->getEntity()->getLastDamageCause();
        if (!$cause instanceof EntityDamageByEntityEvent) return;
        $damager = $cause->getDamager();
        if (!$damager instanceof Player) return;
        if ($boss instanceof ForgottenNome) {
            $damager->getInventory()->addItem($nome[array_rand($nome)]);
        } elseif ($boss instanceof ForgottenKing) $damager->getInventory()->addItem($king[array_rand($king)]);
    }
}
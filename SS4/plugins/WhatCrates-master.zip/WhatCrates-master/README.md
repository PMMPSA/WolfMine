[![](https://poggit.pmmp.io/shield.state/WhatCrates)](https://poggit.pmmp.io/p/WhatCrates)
[![](https://poggit.pmmp.io/shield.api/WhatCrates)](https://poggit.pmmp.io/p/WhatCrates)
[![](https://img.shields.io/discord/323953253458903040.svg)](https://discord.gg/ekUFD8z)

WhatCrates is a plugin that allows you to make any block you want as a "WhatCrate".
Open Crates and win prizes!

# Setup
1. Put the WhatCrates.phar in your /plugins folder.
2. Start your server.
3. Go into your /plugin_data folder.
4. If you want you can change now the raffle-speed and spinning-times in the config.yml
5. Go into your WhatCrates.yml
6. Setup your WhatCrates there.
7. Restart your server.
8. Have fun!

# Commands
/whatcrates key give [player] [type] [amount]
/whatcrates ui

# Permissions
whatcrates - gives permission to all whatcrates commands.

# Thanks to Zap-Hosting & JetBrains!
## Zap-Hosting
Zap-Hosting.com is a company hosting Gameservers, VPS, Rootservers and much more!

They gave me a Server for testing my open source projects!

You still need a cheap & good VPS or a strong Rootserver? Then follow the links below:

(You can also use my code: schdow-10 to get a 10% discount for every product for EVER.)

[VPS](https://zap-hosting.com/schdowvserver)

[Rootserver](https://zap-hosting.com/schdowroot)
## JetBrains
This plugin was made with JetBrains Software.

# DailyRewards
Get rewards DAILY

# Commands
 - /dailyrewards
 - /dailyreward
 - /rewards
###### All commands does the same function

# Builds
[![Poggit-CI](https://poggit.pmmp.io/ci.badge/PocketEssential/DailyRewards/DailyRewards)](https://poggit.pmmp.io/ci/PocketEssential/DailyRewards/DailyRewards)

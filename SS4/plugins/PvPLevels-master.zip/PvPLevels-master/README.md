# PvPLevels
PocketMine-MP Plugin for leveling up by getting kills

[![Poggit-CI](https://poggit.pmmp.io/ci.badge/corytortoise/PvPLevels/PvPLevels)](https://poggit.pmmp.io/ci/corytortoise/PvPLevels/PvPLevels)

Plugin Request from JoshXX.

PvPLevels is a plugin that implements a level system for PvP(Plus basic stats). This plugin saves the number of kills and deaths of each player. When a player reaches one of the kill amounts defined in config.yml, the player will reach that level and the configured commands, if you have added any, will be run. All stats, including Kills, Deaths, KDR, and Level can be seen with the command /pvpstats. You can see the stats of another online player with /pvpstats [playername].

A ton of credit should go to SOFe, I would be clueless without [this](https://forums.pmmp.io/threads/handling-data-with-data-objects-and-managing-player-sessions.324/) tutorial. Also, credit to Awzaw for pointing out my mistakes.

*Please report all bugs and issues so I can address them.*

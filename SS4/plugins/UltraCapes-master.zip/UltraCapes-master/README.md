# UltraCapes
Everyone likes Capes. With this Plugin you can add them to your Pocketmine-MP Server! 
You can choose a Cape by using the command /cape. Then an UI with the Capes you can choose will be opened.

# Important:

• FormAPI must be installed!


# Features:
   
• Permissions for using all Capes or single Capes!
   
• Easy Usage via UI!
  
• 8 Capes!


# TO DO:
  
• Adding/Configureable Capes

• Adding FormAPI as library


# Permissions:

• cape.all:
description: Allows using all Capes.

• cape.cmd:
description: Allows opening the UI.

• blue_creeper.cape:
description: Blue Creeper Cape Permissiom

• enderman.cape:
description: Enderman Cape Permission

• energy.cape:
description: Energie Cape Permission

• fire.cape:
description: Fire Cape Permission

• red_creeper.cape:
description: Red Creeper Cape Permission

• turtle.cape:
description: Turtle Cape Permission

• pickaxe.cape:
description: Pickaxe Cape Permission

• firework.cape:
description: Firework Cape Permission


Have fun with this plugin on your Server!
 
# Note


• If you have problems open an Issue or contact me on Discord:
  @->("SυρҽɾSƚυʅʅҽ007")#4539 

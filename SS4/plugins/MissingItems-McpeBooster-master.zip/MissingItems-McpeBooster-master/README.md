# Pocketmine MissingItems Plugin by @McpeBooster  [![](https://poggit.pmmp.io/shield.api/MissingItems)](https://poggit.pmmp.io/p/c)



<br>

# Explanations

The MissingItems is a plugin for Pocketmine which add's features which are not added in PmmP at the moment!





# News:

Added Custom Banners

# Features

 - Create a custom Banner with a GUI

# Phar:

get the latest .phar from the release folder




# How to use:





| Step | Description |
| --- | --- |
| 1 | type "/banner" |
| 2 | customize your banner in the GUI |
| 3 | get your banner and use it |





# Commands:

| Command | Description | Permission |
| --- | --- | --- |
| /banner | open the banner GUI | missingitems.banner |





# YouTube Video:

[![Alt text](https://img.youtube.com/vi/0q098qCL_MQ/0.jpg)](https://www.youtube.com/watch?v=0q098qCL_MQ)

Video by @McpeBooster: https://youtu.be/0q098qCL_MQ

[![Alt text](https://img.youtube.com/vi/mAABC0ZmmWk/0.jpg)](https://www.youtube.com/watch?v=mAABC0ZmmWk)

Video by DarkiPlayzMC: https://youtu.be/mAABC0ZmmWk









# Contact details:

Twitter: https://twitter.com/McpeBooster

YouTube: https://youtube.com/McpeBooster

GitHub: https://github.com/McpeBooster

Website: http://McpeBooster.tk

E-Mail: mcpebooster@gmail.com

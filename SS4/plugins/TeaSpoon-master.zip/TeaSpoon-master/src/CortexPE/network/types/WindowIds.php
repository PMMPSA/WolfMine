<?php


namespace CortexPE\network\types;


interface WindowIds {
	public const ANVIL = 2;
	public const ENCHANT = 3;
	public const BEACON = 4;
}
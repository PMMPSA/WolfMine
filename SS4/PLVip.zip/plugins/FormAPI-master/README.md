# FormAPI
<a href="https://discord.gg/MzKQpWZ"><img src="https://discordapp.com/api/guilds/412491783486832640/embed.png" alt="Discord server"/></a>

Simple API for creating forms for MCPE clients (PocketMine only)

# CmdSnooper
Spy on what commands are being ran in your server, with this PocketMine plugin!

Commands:
- /snoop

Permissions:
- snoop.command

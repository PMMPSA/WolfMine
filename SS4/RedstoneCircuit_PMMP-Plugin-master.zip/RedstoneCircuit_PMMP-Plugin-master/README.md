# RedstoneCircuit_PMMP-Plugin
This plugin makes the redstone circuit will work.

This plugin used nukkit source.

## Download
[ClickHere](https://github.com/tedo0627/RedstoneCircuit_PMMP-Plugin/releases/download/1.0.1/RedstoneCircuit_v1.0.1.phar)
